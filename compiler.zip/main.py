def main():
    pass
    
if __name__ == "main":
    main()